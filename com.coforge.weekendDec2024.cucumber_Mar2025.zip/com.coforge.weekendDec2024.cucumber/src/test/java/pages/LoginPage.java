package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver rdriver) {

		driver = rdriver;
		PageFactory.initElements(rdriver, this);
		
		System.out.println("==================page object modal - suing pageFcatory=======================");

	}

	@FindBy(name = "username")
	WebElement txtUser;

	@FindBy(css = "[name='password']")
	WebElement txtPass;

	
	@FindBy(tagName  = "button")
	WebElement btnLogin;
	
	@FindBy(className   = "oxd-userdropdown-name")
	WebElement userDropDown;
	
	@FindBy(partialLinkText  = "Logo")
	WebElement btnLogout;
	
	// methods
	public void enterUser(String user) {

		txtUser.sendKeys(user);
	}

	public void enterPass(String pwd) {

		txtPass.sendKeys(pwd);
	}
	
	
	public void clickLoginButton() {

		btnLogin.click();;
	}
	
	public void clickUserDropDown() {

		userDropDown.click();;
	}
	
	public void clickLogoutButton() {

		btnLogout.click();;
	}

}
