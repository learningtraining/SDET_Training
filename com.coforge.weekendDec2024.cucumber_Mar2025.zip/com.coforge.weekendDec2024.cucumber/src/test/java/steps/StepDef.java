package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;

public class StepDef {

//auto-import - remove unused import ---- Ctrl+Shift+O
	WebDriver driver;
	LoginPage lp;
	
	
	@Before       //hooks
	public void setup(Scenario sc) {
		
		
		System.out.println("=====================inside setup=========================");
		System.out.println("Scenario Name: " + sc.getName());
		System.out.println("=====================inside setup=========================");
	}
	
	
	@After       //hooks
	public void teardown() {
		
		
		System.out.println("=====================inside teardown=========================");
		
	}
	
	
	
	
	
	
	
	
	
	
	@Given("User Launch Chrome browser")
	public void launchApp() {
		
		System.out.println("launching chrome browser");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		
		//Page Object
		lp = new LoginPage(driver);
		
		
		
		
	    
	}

	@When("User opens URL {string}")
	public void user_opens_URL(String appURL) {
		
		System.out.println("Application URL: " + appURL);
		driver.get(appURL);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	   
	}

	@When("User enters Username as {string} and Password as {string}")
	public void user_enters_Username_as_and_Password_as(String user, String pwd) {
	    
		
		lp.enterUser(user);
		lp.enterPass(pwd);
//		driver.findElement(By.name("username")).sendKeys(user);
//		driver.findElement(By.name("password")).sendKeys(pwd);
	}

	@When("Click on Login")
	public void click_on_Login() {
		
//		driver.findElement(By.tagName("button")).click();
		lp.clickLoginButton();
	    
	}

	@Then("Page URL should contains be {string}")
	public void page_URL_should_contains_be(String expURL) throws Exception {
		
		Thread.sleep(3000);
		System.out.println("Application URL: " + driver.getCurrentUrl());
		Assert.assertTrue(driver.getCurrentUrl().contains(expURL));
	    
	}

	@When("User click on user dropdown")
	public void user_click_on_user_dropdown() throws Exception {
		Thread.sleep(3000);
//		driver.findElement(By.className("oxd-userdropdown-name")).click();
		lp.clickUserDropDown();
	    
	}

	@When("User click on Logout")
	public void user_click_on_Logout() throws Exception {
	    
		Thread.sleep(3000);
//		driver.findElement(By.partialLinkText("Logo")).click();
		
		lp.clickLogoutButton();
		
	}

	@Then("Close browser")
	public void close_browser() throws Exception {
		
		Thread.sleep(5000);
		driver.close();
		driver.quit();
	    
	}
	
	
	

}
