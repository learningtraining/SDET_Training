package reqres;

import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class TC01_GET_Listuser2 {
	
	
	
	@Test
	public void verifyListUserAPI() {
		
		
		baseURI = "";
		
//		Response resp = RestAssured.get("https://reqres.in/api/users?page=2");
		
		//given
		//when
		//then
		
		
		given().
		
		when().
		
		
		then();
		
		
		
	}

}
