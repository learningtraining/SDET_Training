package cloudBrowserStack;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.remote.MobileCapabilityType;
import utility.Constants;

public class BS_NativeApp {
	
	WebDriver driver;
	
//	public static final String USERNAME = "";
//	public static final String AUTOMATE_KEY = "";
	
	public static final String USERNAME = "";
	public static final String AUTOMATE_KEY = "";
	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
	
	@BeforeTest
	public void setup() throws Exception {
		
		System.out.println("launching an application");
		DesiredCapabilities caps = new DesiredCapabilities();
		
		
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Google Pixel 7 Pro");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13.0");
		caps.setCapability(MobileCapabilityType.APP, "bs://28a03dfd6d0afc720f2b9ee4a4815bd81c99203c");
		caps.setCapability("appiumVersion", "1.21.0");
		
//
//		
//		System.out.println("access devive details from XML file: " + deviceDetails);
//		
//		
//		
//		if(deviceDetails.equalsIgnoreCase("ipad")) {
//			//device1
//			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPad Pro 11 2024");
//			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
//
//			
//		}
//		else if(deviceDetails.equalsIgnoreCase("iOSMobile")) {
//			
////			//device1
//			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 13 pro");
//			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
//			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "15");
//		}
//		
//		else if(deviceDetails.equalsIgnoreCase("androidMobile")) {
//			
////			//device1
//			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 6 Pro");
//			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
////			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "15");
//		}
//
//		
//		else {
//			
//			//device2
//			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 12 pro");
//			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
//			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "16");
//		}
//		



		
		
		//browserStackDetails
		caps.setCapability("build", "Coforge Weekend: iOS/Android - v4.0");
		caps.setCapability("name", "Run on device - NOP comm Test on cloud -iOS/Android");

		driver = new RemoteWebDriver(new URL(URL), caps);
		
		
//		driver.get(Constants.bs_appURL);
//		driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
		Thread.sleep(5000);
		
		
	}
	
	@AfterTest
	public void teardown() throws Exception {
		
		System.out.println("closing an application");
		Thread.sleep(5000);
		driver.close();
		driver.quit();
	}
	
	@Test
	public void SampleAppTest() {
		//click on OS
				driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"OS\"]")).click();
				//click on SMS messaging
				driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"SMS Messaging\"]")).click();
			
		
	}

}
