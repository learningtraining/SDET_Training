package utility;

public class Constants {
	
	
	//sampleApp
	public static final String hrmApp = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
	public static final String sampleApp = "http://only-testing-blog.blogspot.com/2013/11/new-test.html";
	public static final String irctcApp = "https://www.irctc.co.in/nget/train-search";
	public static final int delayTest = 20;
	
	public static final String email = "Admin";
	public static final String pass = "admin123";
	
	//API
	
	
	
	
	//MobileAbutomation
	
	
	
	//Cloud Devices
	
	public static final String bs_userName = "";
	public static final String bs_accesskey = "";
	

}
