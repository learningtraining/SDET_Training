package rdExample_SampleApp;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class RD_SampleApp_FindElement {
	
//	AppiumDriver driver;
	AppiumDriver<MobileElement> driver;
	
	@BeforeTest
	public void setup() throws Exception {
		
		String AppiumServer = "http://localhost:4723/wd/hub";
		
		
		DesiredCapabilities caps = new DesiredCapabilities();
		
		//DevicesDetails
		caps.setCapability("udid", "c60c1a73");								//adb devices
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "13.0");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13.0");
		
		
		
		caps.setCapability("appPackage", "io.appium.android.apis");
		caps.setCapability("appActivity", "io.appium.android.apis.ApiDemos");
		
		
		//adb shell dumpsys window | find "mCurrentFocus"
		//mCurrentFocus=Window{612aacc u0 io.appium.android.apis/io.appium.android.apis.ApiDemos
		
		driver = new AppiumDriver<MobileElement>(new URL(AppiumServer), caps);     //create a device session
		
	
		Thread.sleep(2000);
	
	}
	
	
	
	
	
	
	
	
	
	
	@AfterTest
	public void teardown() throws Exception {
		Thread.sleep(5000);
		driver.closeApp();
		System.out.println("dis-connecting to devices");
	}
	
	
	
	
	
	
	@Test
	public void verifyAPIDemoAppTest() {
		
		
		System.out.println("Installing app on real device");
		//uiAutomatorViewer
		driver.findElement(By.id("android:id/text1")).click();    //multiple match
		
		
		
		
		
	}
	
	
	

}
