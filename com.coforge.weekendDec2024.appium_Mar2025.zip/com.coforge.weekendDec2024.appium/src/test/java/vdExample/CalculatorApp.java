package vdExample;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class CalculatorApp {
	
	AppiumDriver<MobileElement> driver;
	
	
	@BeforeTest
	public void setup() throws Exception {
		
		System.out.println("connect to device");
		String appiumServer = "http://localhost:4723/wd/hub/";
		
		DesiredCapabilities caps = new DesiredCapabilities();
		
		//device details
		caps.setCapability("udid", "emulator-5554");									//adb devices
		caps.setCapability("platformName", "android");
		caps.setCapability("platformVersion", "11.0");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.0");
		
//		//application details
//		caps.setCapability("", "");
		
		
		
		driver = new AppiumDriver<MobileElement>(new URL(appiumServer), caps);      //create a driver session
		
		
		
		
	}
	
	
	
	

	@AfterTest
	public void teardown() {
		
		System.out.println("connection closed");
		
	}
	
	
	
	
	@Test
	public void verifyAddTest() {
		
		
		System.out.println("add test execution started.");
		
		
	}
	

}
