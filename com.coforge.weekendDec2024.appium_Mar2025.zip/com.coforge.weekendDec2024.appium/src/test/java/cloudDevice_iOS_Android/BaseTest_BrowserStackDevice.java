package cloudDevice_iOS_Android;

import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.appium.java_client.remote.MobileCapabilityType;
import utility.Constants;

public class BaseTest_BrowserStackDevice {
	
	
	WebDriver driver;
	public static final String USERNAME = "";
	public static final String AUTOMATE_KEY = "";
	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";


	
	@Parameters("platform_Coforge")
	@BeforeMethod
	public void setUp(String platformFromXML) throws Exception {

		
		DesiredCapabilities caps = new DesiredCapabilities();
        
		
		
		
		
//		String platform = Constants.pltform_cloud;
		String platform = platformFromXML;
	
//		System.out.println("fetch platform value from Constant: " + platform);
		System.out.println("fetch platform value from XML file: " + platformFromXML);
		
		if(platform.equalsIgnoreCase("IOS")) {
			
			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 12 pro");
			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "14");
		}
		
		else if(platform.equalsIgnoreCase("android")) {
			
			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Samsung Galaxy S23");
			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13.0");
			
		}
		
		else if(platform.equalsIgnoreCase("ipad")) {
			
			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPad Air 4");
			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "14");
			
		}
		
		else {
			
			System.out.println("Default execution");
			
			caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Google Pixel 8");
			caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "14.0");

			caps.setCapability("appiumVersion", "1.21.0");
			
		}
		
		
		

		
		
		
		
		
		
//		caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.CHROME);
//		caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.CHROMIUM);
//		caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.SAFARI);
		
		caps.setCapability("browserName", "chromium");
		
		caps.setCapability("build", "Coforge Weekend: iOS/Android - v3.0 parallel");
		caps.setCapability("name", "Run on device - NOP comm Test on cloud -iOS/Android");

		driver = new RemoteWebDriver(new URL(URL), caps);
		
		driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");

	}
	
	@AfterTest
	public void closeSession() throws Exception {
		
		Thread.sleep(5000);
		driver.quit();
	}
	

}
