package cloudDevice_iOS_Android;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class NOPCommTest extends BaseTest_BrowserStackDevice{
	
	//WebDriver driver;
	
	@Test
	public void verifyLoginTest() {
		
		System.out.println("test execution started....");
		
		driver.findElement(By.cssSelector("#Email")).clear();
		driver.findElement(By.cssSelector("#Email")).sendKeys("admin@yourstore.com");
		
		
		
		driver.findElement(By.cssSelector(".password")).clear();
		driver.findElement(By.cssSelector(".password")).sendKeys("admin");
		
		
		driver.findElement(By.cssSelector("#RememberMe")).click();
		
		
		driver.findElement(By.cssSelector("[type=\"submit\"]")).click();
		
		
	}

}
